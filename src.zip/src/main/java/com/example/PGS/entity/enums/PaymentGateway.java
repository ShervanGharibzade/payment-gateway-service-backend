package com.example.PGS.entity.enums;

public enum PaymentGateway {
    ZARINPAL,
    IDPAY,
    PAYPING
}
