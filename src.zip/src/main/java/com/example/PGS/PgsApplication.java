package com.example.PGS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PgsApplication.class, args);
	}

}
