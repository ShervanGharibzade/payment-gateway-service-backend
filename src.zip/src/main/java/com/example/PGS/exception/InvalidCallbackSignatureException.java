package com.example.PGS.exception;


public class InvalidCallbackSignatureException extends BusinessException {

    public InvalidCallbackSignatureException(String message) {
        super(message);
    }
}
