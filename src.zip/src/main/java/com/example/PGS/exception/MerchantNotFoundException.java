package com.example.PGS.exception;

public class MerchantNotFoundException extends BusinessException {

    public MerchantNotFoundException(String message) {
        super(message);
    }
}